H2X Studio — Font Package
==========================

Bộ font dùng trong Fee Proposal Generator (file PPTX xuất ra không nhúng
được font, nên cần cài các font này vào máy để xem/sửa đúng như thiết kế).

Cách cài trên Windows:
1. Giải nén file zip này.
2. Chọn tất cả các file font (.otf, .ttf).
3. Bấm chuột phải → "Install" (hoặc "Install for all users" nếu dùng
   chung máy với người khác).
4. Mở lại PowerPoint nếu đang mở sẵn để font được nhận diện.

Cách cài trên macOS:
1. Giải nén file zip này.
2. Bấm đúp vào từng file font → bấm "Install Font" trong Font Book.

Danh sách font:
- Toma Sans Light / Regular / Bold / SemiBold  (dùng cho nội dung, body text)
- Playfair Display Regular / Italic / SemiBold  (dùng cho tiêu đề, logo)
